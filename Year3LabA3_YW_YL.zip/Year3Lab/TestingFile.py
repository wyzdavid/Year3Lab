# -*- coding: utf-8 -*-
"""
Created on Thu Jan 21 19:09:09 2021

@author: wyzda
"""

import os
import sys

import pandas as pd


file_dir = os.path.dirname(__file__)
sys.path.append(file_dir)

#%%

import scipy as sp
import numpy as np
import matplotlib.pyplot as plt


import TransferMatrix as TM
interpolation = TM.Inter()



#%%
Data = open('bkglass.txt', "r")

Data2 = pd.read_csv('bkglass.txt')

#print(Data.read())

#print(Data2.shape)



wavelength , ndata , kdata = sp.loadtxt('bkglass.txt', skiprows = 1, delimiter = '	',unpack = True)

#print(wavelength)


wavelengthpoints = np.linspace(330, 2500, 1000)




InterpolatedNData = interpolation.CSI(wavelength, ndata,wavelengthpoints)

#print(InterpolatedNData)
#%%

plt.figure(figsize=  (8,6))
plt.xlim(330, 2500 )


plt.ylabel('Refractive Index',fontsize=13)
plt.xlabel('Wavelength (nm)',fontsize=13)
plt.title('Refractive Index of BK7 glass',fontsize=17)


plt.plot(wavelengthpoints,InterpolatedNData,label='Interpolated Refractive Index',linestyle='--')

plt.plot(wavelength,ndata,'.',label='Refractive Index Data for BK7')


plt.legend()

plt.show()

#%%

#Using Sellmeier Equation

def sellmeier(x): #for BK7
    
    nsquare = 1 + (1.03961212 * (x**2))/(x**2 - (6*1e3)**1) + (0.231792344 * (x**2))/(x**2 - (2.00179*1e4)**1) + (1.01046945 * (x**2))/(x**2 - (1.03560653 * 1e8)**1)
    return np.sqrt(nsquare)


calculatedn = sellmeier(wavelengthpoints)

plt.figure(figsize=  (8,6))
plt.xlim(330, 2500 )


plt.ylabel('Refractive Index',fontsize=13)
plt.xlabel('Wavelength (nm)',fontsize=13)
plt.title('Refractive Index of BK7 glass',fontsize=17)

plt.plot(wavelengthpoints,InterpolatedNData,label='Interpolated Refractive Index',linestyle='-.')

plt.plot(wavelengthpoints,calculatedn,label='Calculated Refractive Index',linestyle='--')


plt.legend()

plt.show()


#%%


Au_wavelength , Au_ndata , Au_kdata = sp.loadtxt('Au.txt', skiprows = 1, delimiter = '	',unpack = True)


Au_WavelengthPoints = np.linspace(210, 1000, 1000)


Au_InterpolatedN = interpolation.CSI(Au_wavelength,Au_ndata,Au_WavelengthPoints)

Au_Interpolatedk = interpolation.CSI(Au_wavelength,Au_kdata,Au_WavelengthPoints)


plt.figure(figsize= (8,6))
plt.ylabel('Refractive Index',fontsize=13)
plt.xlabel('Wavelength (nm)',fontsize=13)
plt.title('Refractive Index of Gold',fontsize=17)

plt.plot(Au_WavelengthPoints,Au_InterpolatedN,label='Real Refractive Index',linestyle='-.')

plt.plot(Au_WavelengthPoints,Au_Interpolatedk,label='Imaginary Refractive Index',linestyle='--')

plt.legend()

plt.show()


#%%

T_M = TM.TransferM()

#%%

MgF2_WavelengthPoints = np.linspace(330, 900, 650)

MgF2_wavelength , MgF2_ndata , MgF2_kdata = sp.loadtxt('MgF2.txt', skiprows = 1, delimiter = '	',unpack = True)

MgF2_intern = interpolation.CSI(MgF2_wavelength,MgF2_ndata,MgF2_WavelengthPoints)
MgF2_interk = interpolation.CSI(MgF2_wavelength,MgF2_kdata,MgF2_WavelengthPoints)
MgF2_refdata = np.zeros(len(MgF2_WavelengthPoints))

for i in range(len(MgF2_WavelengthPoints)):
    MgF2_refdata[i] = MgF2_intern[i][0] + 1j * MgF2_interk[i][0]


BK7_wavelength , BK7_ndata , BK7_kdata = sp.loadtxt('bkglass.txt', skiprows = 1, delimiter = '	',unpack = True)
BK7_intern = interpolation.CSI(BK7_wavelength,BK7_ndata,MgF2_WavelengthPoints)
BK7_interk = interpolation.CSI(BK7_wavelength,BK7_kdata,MgF2_WavelengthPoints)
BK7_refdata = np.zeros(len(MgF2_WavelengthPoints))

for i in range(len(MgF2_WavelengthPoints)):
    BK7_refdata[i] = BK7_intern[i][0] + 1j * BK7_interk[i][0]

#%%


MgF2_OnBK7_R = np.zeros(len(MgF2_WavelengthPoints))


MgF2_OnBK7_pos = [0,200]
MgF2_OnBK7_InAngle = 0
MgF2_OnBK7_s_or_p = 's'

#print(BK7_refdata)
'''
TestWave = 550
MgF2_OnBK7_n = [1,1.38,1.52]
MgF2_OnBK7_R = T_M.Mmatrix( MgF2_OnBK7_n , MgF2_OnBK7_pos , TestWave , MgF2_OnBK7_InAngle , MgF2_OnBK7_s_or_p )

print(MgF2_OnBK7_R)
'''
#%%

for i in range(len(MgF2_WavelengthPoints)):
    MgF2_OnBK7_n = [1,MgF2_intern[i],BK7_intern[i]]
    #print(MgF2_OnBK7_pos)
    TestWave = MgF2_WavelengthPoints[i]
    MgF2_OnBK7_R[i] = T_M.Mmatrix( MgF2_OnBK7_n , MgF2_OnBK7_pos , TestWave , MgF2_OnBK7_InAngle , MgF2_OnBK7_s_or_p )[1]

plt.figure(figsize= (8,6))
plt.plot(MgF2_WavelengthPoints,MgF2_OnBK7_R,label='Reflectance of MgF2 on BK7',linestyle='--')
plt.ylabel('Reflectance',fontsize=13)
plt.xlabel('Wavelength (nm)',fontsize=13)
plt.legend()
plt.show()

#%%

Task8_Wavelength = 350
Task8_InAngle = (0/180) * np.pi
T8_RefIndex = np.linspace(1, 2, 1000)
T8_polarization = 's'
T8_RI_minimization = np.zeros(1000)

#At 350nm BK7 n approximately 1.539

for i in range(len(T8_RefIndex)):
    testn = [1,T8_RefIndex[i],1.539]
    testpos = [0,200]
    T8_RI_minimization[i] = T_M.Mmatrix(testn,testpos, Task8_Wavelength, Task8_InAngle, T8_polarization )[1]

for i in range(len(T8_RI_minimization)):
    if T8_RI_minimization[i] == min(T8_RI_minimization):
        print('Minimized Refractive Index is',T8_RefIndex[i])



T8_Pos = np.linspace(10, 500, 2000)
T8_thickness_minimization = np.zeros(2000)

for i in range(len(T8_Pos)):
    testn = [1,1.27627,1.539]
    testpos = [0,T8_Pos[i]]
    T8_thickness_minimization[i] = T_M.Mmatrix(testn,testpos, Task8_Wavelength, Task8_InAngle, T8_polarization )[1]

for i in range(len(T8_thickness_minimization)):
    if T8_thickness_minimization[i] == min(T8_thickness_minimization):
        print('Minimized Thickness is',T8_Pos[i])
        print('Minimum Reflectance is',T8_thickness_minimization[i])

#%%


Au_wavelength , Au_ndata , Au_kdata = sp.loadtxt('Au.txt', skiprows = 1, delimiter = '	',unpack = True)

AuOnBK7_WavelengthPoints = np.linspace(330, 2400, 1000)

AuBK7_InterpolatedN = interpolation.CSI(Au_wavelength,Au_ndata,AuOnBK7_WavelengthPoints)
AuBK7_Interpolatedk = interpolation.CSI(Au_wavelength,Au_kdata,AuOnBK7_WavelengthPoints)
#print(AuBK7_InterpolatedN)

AuBK7_refdata = np.zeros(0)
for i in range(len(AuOnBK7_WavelengthPoints)):
    AuBK7_refdata = np.append( AuBK7_refdata , AuBK7_InterpolatedN[i][0] +  float(AuBK7_Interpolatedk[i][0])*1j)
    #print(float(AuBK7_Interpolatedk[i][0]))

#print(AuBK7_refdata)
BK7_wavelength , BK7_ndata , BK7_kdata = sp.loadtxt('bkglass.txt', skiprows = 1, delimiter = '	',unpack = True)
BK7wAu_intern = interpolation.CSI(BK7_wavelength,BK7_ndata,AuOnBK7_WavelengthPoints)
BK7wAu_interk = interpolation.CSI(BK7_wavelength,BK7_kdata,AuOnBK7_WavelengthPoints)
#print(BK7wAu_interk,len(BK7wAu_intern))

BK7wAu_refdata = np.zeros(0)
for i in range(len(AuOnBK7_WavelengthPoints)):
    BK7wAu_refdata = np.append(BK7wAu_refdata, BK7wAu_intern[i][0] + float(BK7wAu_interk[i][0])*1j )


#%%
Task9_InAngle = (0/180) * np.pi
T9_polarization = 's'
T9_Pos = [0,20]

AuBK7_R = np.zeros(1000)
AuBK7_T = np.zeros(1000)
for i in range(len(AuOnBK7_WavelengthPoints)):
    AuBK7_n = [1,AuBK7_refdata[i],BK7wAu_refdata[i]]
    TestWave = AuOnBK7_WavelengthPoints[i]
    AuBK7_R[i] = T_M.Mmatrix( AuBK7_n , T9_Pos , TestWave , Task9_InAngle , T9_polarization )[1]
    AuBK7_T[i] = T_M.Mmatrix( AuBK7_n , T9_Pos , TestWave , Task9_InAngle , T9_polarization )[2]


plt.figure(figsize= (8,6))
plt.ylabel('Reflectance',fontsize=13)
plt.xlabel('Wavelength (nm)',fontsize=13)
plt.plot(AuOnBK7_WavelengthPoints,AuBK7_R,label='Reflectance of Au on BK7',linestyle='--')
plt.legend()
plt.show()


AuBK7_thicknessVariationT = np.zeros(1000)
AuOnBK7_thickness = np.linspace(10, 100, 1000)
AuBK7_Wavelength = 506
AuBK7_thicknessVariationR = np.zeros(1000)

for i in range(len(AuOnBK7_WavelengthPoints)):
    AuBK7_n = [1,0.755+1.9565j,1.521+4.49E-07j]
    Task9_Pos = [0,AuOnBK7_thickness[i]]
    AuBK7_thicknessVariationT[i] = T_M.Mmatrix( AuBK7_n , Task9_Pos , AuBK7_Wavelength , Task9_InAngle , T9_polarization )[2]
    AuBK7_thicknessVariationR[i] = T_M.Mmatrix( AuBK7_n , Task9_Pos , AuBK7_Wavelength , Task9_InAngle , T9_polarization )[1]

plt.figure(figsize= (8,6))
plt.ylabel('Reflectance',fontsize=13)
plt.xlabel('Thickness of Gold film (nm)',fontsize=13)
plt.plot(AuOnBK7_thickness,AuBK7_thicknessVariationR,label='Variation with thickness of Au coating for 506 nm',linestyle='--')
plt.legend()
plt.show()


def absorb (R,T):
    return 1 - R - T

for i in range(len(AuBK7_R)):
    if absorb(AuBK7_thicknessVariationR[i],AuBK7_thicknessVariationT[i]) == max(absorb(AuBK7_thicknessVariationR,AuBK7_thicknessVariationT)):
        print('Maximum absorbance is',absorb(AuBK7_thicknessVariationR[i],AuBK7_thicknessVariationT[i]),'at',AuOnBK7_thickness[i],'nm')

#print(absorb(AuBK7_R[0],AuBK7_T[0]))



#%%


Ta2O5_wavelengthmicro , Ta2O5_ndata = sp.loadtxt('Ta2O5.txt', skiprows = 1, delimiter = '	',unpack = True)

Ta2O5_wavelengthmicro , Ta2O5_kdata = sp.loadtxt('Ta2O5k.txt', skiprows = 1, delimiter = '	',unpack = True)

MgF2_wavelengthmicro , MgF2_UpRange = sp.loadtxt('MgF2Data.txt', skiprows = 1, delimiter = '	',unpack = True)

TaMgStack_WavelengthPoints = np.linspace(500,2300, 1000)
Ta2O5_wavelength = Ta2O5_wavelengthmicro * 1000
MgF2_wavelength_plus = MgF2_wavelengthmicro * 1000


Ta2O5_intern = interpolation.CSI(Ta2O5_wavelength,Ta2O5_ndata,TaMgStack_WavelengthPoints)
Ta2O5_interk = interpolation.CSI(Ta2O5_wavelength,Ta2O5_kdata,TaMgStack_WavelengthPoints)

Ta2O5_refdata = np.zeros(0)
for i in range(len(TaMgStack_WavelengthPoints)):
    Ta2O5_refdata = np.append(Ta2O5_refdata, Ta2O5_intern[i][0] + float(Ta2O5_interk[i][0])*1j )
    
MgF2_refdata = interpolation.CSI(MgF2_wavelength_plus,MgF2_UpRange,TaMgStack_WavelengthPoints)
#MgF2_interk = interpolation.CSI(MgF2_wavelength,MgF2_kdata,TaMgStack_WavelengthPoints)

Au500_intern = interpolation.CSI(Au_wavelength,Au_ndata,TaMgStack_WavelengthPoints)
Au500_interk = interpolation.CSI(Au_wavelength,Au_kdata,TaMgStack_WavelengthPoints)

Au500_refdata = np.zeros(0)
for i in range(len(TaMgStack_WavelengthPoints)):
    Au500_refdata = np.append(Au500_refdata, Au500_intern[i][0] + float(Au500_interk[i][0])*1j )


Ta2O5_refdata = np.zeros(0)
for i in range(len(TaMgStack_WavelengthPoints)):
    Ta2O5_refdata = np.append(Ta2O5_refdata, Ta2O5_intern[i][0] + float(Ta2O5_interk[i][0])*1j )
'''
MgF2_refdata = np.zeros(0)
for i in range(len(TaMgStack_WavelengthPoints)):
    MgF2_refdata = np.append(MgF2_refdata, MgF2_intern[i][0] + float(MgF2_interk[i][0])*1j )
'''

#%%

ta633 =np.array([700])
Ta2O5_intern633 = interpolation.CSI(Ta2O5_wavelength,Ta2O5_ndata,ta633)
Ta2O5_interk633 = interpolation.CSI(Ta2O5_wavelength,Ta2O5_kdata,ta633)

MgF2_intern633 = interpolation.CSI(MgF2_wavelength_plus,MgF2_UpRange,ta633)
#MgF2_interk633 = interpolation.CSI(MgF2_wavelength,MgF2_kdata,ta633)

Au_intern633 = interpolation.CSI(Au_wavelength,Au_ndata,ta633)
Au_interk633 = interpolation.CSI(Au_wavelength,Au_kdata,ta633)

BK7_intern633 = interpolation.CSI(BK7_wavelength,BK7_ndata,ta633)
#BK7_interk633 = interpolation.CSI(BK7_wavelength,BK7_kdata,ta633)

BK7_refdata633 = BK7_intern633[0]

Ta2O5_refdata633 = Ta2O5_intern633[0] + Ta2O5_interk633[0] * 1j

MgF2_refdata633 = MgF2_intern633[0] 
#+ MgF2_interk633[0] * 1j

Au_refdata633 = Au_intern633[0] + Au_interk633[0] * 1j

print(Ta2O5_refdata633,MgF2_refdata633,Au_refdata633)

#%%

TargetWavelength = 1266

#Ta2O5_refdata633 = np.array([5+0j])
#MgF2_refdata633 = np.array([2+0j])

maxRthickness1 = TargetWavelength / (4* Ta2O5_refdata633.real)


maxRthickness2 = TargetWavelength / (4* MgF2_refdata633.real)


def StackPandRI(Number_of_Stacks):
    Pos = [0]
    RefIndex = [1]
    for j in range(Number_of_Stacks):
        Pos.append(maxRthickness1[0]+Pos[-1])
        Pos.append(maxRthickness2[0]+Pos[-1])
        RefIndex.append(Ta2O5_refdata633[0])
        RefIndex.append(MgF2_refdata633[0])
    RefIndex.append(1.515 + 4.09E-07j)
    return Pos, RefIndex


#%%
Number_of_Stacks = 1

Task12_InAngle = 0

T12_polarization = 's'

Task12_Pos,Task12_RefIndex = StackPandRI(Number_of_Stacks)

#print(Task12_Pos,Task12_RefIndex)

#Ta2O5_task11_refdata = [0,]


Au_Task12n = [1,Au_refdata633,1.515 + 4.09E-07j]

AuT12 =  [0,103]
Au_R633  = T_M.Mmatrix( Au_Task12n , AuT12 , TargetWavelength , Task12_InAngle , T12_polarization )[1]
print(Au_R633)



TaMgStack_R633 = T_M.Mmatrix( Task12_RefIndex , Task12_Pos , TargetWavelength , Task12_InAngle , T12_polarization )[1]

print(TaMgStack_R633)

while TaMgStack_R633 < Au_R633:
    Number_of_Stacks += 1 
    Task12_Pos,Task12_RefIndex = StackPandRI(Number_of_Stacks)
    TaMgStack_R633 = T_M.Mmatrix( Task12_RefIndex , Task12_Pos , TargetWavelength , Task12_InAngle , T12_polarization )[1]
    if Number_of_Stacks > 1000:
        break

print(Number_of_Stacks,TaMgStack_R633)


#%%

#Task 13 DBR

Task13Stack = 50

Task13_Pos,Task1x_RefIndex = StackPandRI(Task13Stack)
#print(Task13_Pos,Task1x_RefIndex)

Task13_InAngle = 0
T13_polarization = 's'

T13_R = np.zeros(1000)
for i in range(len(TaMgStack_WavelengthPoints)):
    TestWave = TaMgStack_WavelengthPoints[i]
    layer1n = Ta2O5_refdata[i]
    layer2n = MgF2_refdata[i]
    Task13_RefIndex = [1]
    LayerN = [layer1n,layer2n]*Task13Stack
    Task13_RefIndex = Task13_RefIndex + LayerN + [1.515]
    #print(Task13_RefIndex)
    #[1,Ta2O5_refdata[i],MgF2_refdata[i],Ta2O5_refdata[i],MgF2_refdata[i],Ta2O5_refdata[i],MgF2_refdata[i],1.515]
    T13_R[i] = T_M.Mmatrix(Task13_RefIndex , Task13_Pos , TestWave ,Task13_InAngle , T13_polarization )[1]


plt.figure(figsize= (8,6))
plt.xlabel('Wavelength (nm)',fontsize=13)
plt.ylabel('Reflectance',fontsize=13)
plt.plot(TaMgStack_WavelengthPoints,T13_R,label='R of 50 Stacks of MgF2/Ta2O5',linestyle='--')
plt.legend()
plt.show()


#%%
Task14Stack = 5
T14Pos ,sdasd = StackPandRI(Task14Stack)
T13_matrixStack = np.zeros(1000)
for i in range(1000):
    TestWave = TaMgStack_WavelengthPoints[i]
    Task14_RefIndex = [1]
    layerN = [Ta2O5_refdata[i],MgF2_refdata[i]] *Task14Stack
    Task14_RefIndex = Task14_RefIndex + layerN + [1.515]
    T13_matrixStack[i] = T_M.Mmatrix(Task14_RefIndex , T14Pos , TestWave ,Task13_InAngle , T13_polarization )[0]


T13_matrixAu = np.zeros(1000)
for i in range(1000):
    TestWave = TaMgStack_WavelengthPoints[i]
    Au_Task14n = [1,Au500_refdata[i],1.515]
    T13_matrixAu[i] = T_M.Mmatrix(Au_Task14n , AuT12 , TestWave ,Task13_InAngle , T13_polarization )[0]

#print(T13_matrixStack)
#T13_matrixStackr = np.zeros(500)
#T13_matrixAur = np.zeros(500)

PhaseChangeStack = np.zeros(1000)
PhaseChangeAu = np.zeros(1000)


for i in range(1000):
    PhaseChangeStack[i] = 180* np.arccos(T13_matrixStack[i].real)/np.pi
    PhaseChangeAu[i] = 180* np.arccos(T13_matrixAu[i].real) /np.pi




plt.figure(figsize= (8,6))
plt.xlabel('Wavelength (nm)',fontsize=13)
plt.ylabel('Phase Change (degree)',fontsize=13)
plt.plot(TaMgStack_WavelengthPoints,PhaseChangeAu,label='Phase Change for Au mirror',linestyle='--')
plt.plot(TaMgStack_WavelengthPoints,PhaseChangeStack,label='Phase Change for DBR stack',linestyle='--')
plt.legend()
plt.show()


#%%

#DBR with cavity
AlAs_wavelength, AlAs_n, AlAs_k = sp.loadtxt('AlAs.txt', skiprows = 1, delimiter = '	',unpack = True)

GaAs_wavelengthmicro , GaAs_ndata = sp.loadtxt('GaAsn.txt', skiprows = 1, delimiter = '	',unpack = True)
GaAs_wavelengthmicro , GaAs_kdata = sp.loadtxt('GaAsk.txt', skiprows = 1, delimiter = '	',unpack = True)

AlGaAs_wavelengthmicro , AlGaAs_ndata = sp.loadtxt('AlGaAsn.txt', skiprows = 1, delimiter = '	',unpack = True)
AlGaAs_wavelengthmicro , AlGaAs_kdata = sp.loadtxt('AlGaAsk.txt', skiprows = 1, delimiter = '	',unpack = True)

InGaAs_wavelengthmicro , InGaAs_ndata = sp.loadtxt('InGaAsn.txt', skiprows = 1, delimiter = '	',unpack = True)
InGaAs_wavelengthmicro , InGaAs_kdata = sp.loadtxt('InGaAsk.txt', skiprows = 1, delimiter = '	',unpack = True)

DBRcavity_wavelength = np.linspace(221,820, 1000)

GaAs_wavelength = GaAs_wavelengthmicro * 1000
AlGaAs_wavelength = AlGaAs_wavelengthmicro * 1000
InGaAs_wavelength = InGaAs_wavelengthmicro * 1000

GaAs_intern = interpolation.CSI(GaAs_wavelength,GaAs_ndata,DBRcavity_wavelength)
GaAs_interk = interpolation.CSI(GaAs_wavelength,GaAs_kdata,DBRcavity_wavelength)

AlGaAs_intern = interpolation.CSI(AlGaAs_wavelength,AlGaAs_ndata,DBRcavity_wavelength)
AlGaAs_interk = interpolation.CSI(AlGaAs_wavelength,AlGaAs_kdata,DBRcavity_wavelength)

InGaAs_intern = interpolation.CSI(InGaAs_wavelength,InGaAs_ndata,DBRcavity_wavelength)
InGaAs_interk = interpolation.CSI(InGaAs_wavelength,InGaAs_kdata,DBRcavity_wavelength)

AlAs_refdata = interpolation.CSI(AlAs_wavelength,AlAs_n,DBRcavity_wavelength)

GaAs_refdata = np.zeros(0)
for i in range(len(DBRcavity_wavelength)):
    GaAs_refdata = np.append(GaAs_refdata, GaAs_intern[i][0] + GaAs_interk[i][0]*1j )

AlGaAs_refdata = np.zeros(0)
for i in range(len(DBRcavity_wavelength)):
    AlGaAs_refdata = np.append(AlGaAs_refdata, AlGaAs_intern[i][0] + AlGaAs_interk[i][0]*1j )

InGaAs_refdata = np.zeros(0)
for i in range(len(DBRcavity_wavelength)):
    InGaAs_refdata = np.append(InGaAs_refdata, InGaAs_intern[i][0] + InGaAs_interk[i][0]*1j )

#%%
#print(AlGaAs_refdata)
#%%
'''
DBRcavity_wavelength = np.linspace(221,2000, 1000)
for i in range(1000):
    InGaAs_refdata[i] = 4.446 + 1.17j
    AlGaAs_refdata[i] =3.945 + 0.256j
    GaAs_refdata[i] = 4.205 + 0.371j
    AlAs_refdata[i] = 3.3516
'''
DBRcavity_wavelength = np.linspace(221,820, 1000)

NoFrontStack = 30
NoBackStack = 28

CentralThick = 30

FrontSt = 29.61
FrontSt2 = 31.6
BackSt = 29.61
BackSt2 = 31.6

DBRcavAngle = 0
DBRpolar = 's'

def DBRcavity_pos(frontstackno,fsthick,fsthick2,centralthickness,backstackno,bsthick,bsthick2):
    DBRcavity_pos = [0]
    for i in range(frontstackno):
        DBRcavity_pos.append(fsthick + DBRcavity_pos[-1])
        DBRcavity_pos.append(fsthick2 + DBRcavity_pos[-1])
    DBRcavity_pos.append(centralthickness + DBRcavity_pos[-1])
    DBRcavity_pos.append(centralthickness + DBRcavity_pos[-1])
    for i in range(backstackno):
        DBRcavity_pos.append(bsthick + DBRcavity_pos[-1])
        DBRcavity_pos.append(bsthick2 + DBRcavity_pos[-1])
    return DBRcavity_pos

DBRcav_pos = DBRcavity_pos(NoFrontStack,FrontSt,FrontSt2,CentralThick,NoBackStack,BackSt,BackSt2)
#print(DBRcav_pos)
DBRcavity_R = np.zeros(1000)
for i in range(len(DBRcavity_wavelength)):
    TestWave = DBRcavity_wavelength[i]
    DBRcav_RefIndex = [1]
    LayerF = [GaAs_refdata[i],AlGaAs_refdata[i]] * NoFrontStack
    #LayerB = [AlGaAs_refdata[i],GaAs_refdata[i]] * NoFrontStack
    LayerB = [GaAs_refdata[i],AlAs_refdata[i]] * NoBackStack
    CentralN = [GaAs_refdata[i],InGaAs_refdata]
    DBRcav_RefIndex = DBRcav_RefIndex + LayerF + CentralN + LayerB
    DBRcavity_R[i] = T_M.Mmatrix(DBRcav_RefIndex , DBRcav_pos , TestWave ,DBRcavAngle , DBRpolar)[1]

#print(DBRcav_RefIndex)

Label = 'R of VCSELs with central thickness of 10 nm'
plt.figure(figsize= (8,6))
plt.xlabel('Wavelength (nm)',fontsize=13)
plt.ylabel('Reflectance',fontsize=13)
plt.plot(DBRcavity_wavelength,DBRcavity_R,label=Label,linestyle='--')
plt.legend()
plt.show()

#%%


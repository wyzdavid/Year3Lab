# -*- coding: utf-8 -*-



import scipy as sp
import numpy as np
import matplotlib.pyplot as plt


class MM:
    def CroutMethod (self, InputMatrix = np.array([[0,0],[0,0]])): # This part is the Crout Algorithm for seperating a matrix into a lower and upper diagonal matrix
        
        Dimension = InputMatrix.shape #These parts initiates with empty matrices for the lower and upper matrix, as well as an seperate empty one for the output
        UpperM = np.zeros(Dimension)
        LowerM = np.identity(Dimension[0])
        OutputM = np.zeros(Dimension)
        
        for j in range(Dimension[0]): 
            for i in range (j,Dimension[0]):
                Sum = sum(LowerM[i,k]*UpperM[k,j] for k in range(j))
                LowerM[i,j]= InputMatrix[i,j] - Sum
                UpperM[j,i]= (InputMatrix[j,i] - Sum)/LowerM[j,j]
                
        for i in range(1,Dimension[0]):
            for j in range(i):
                OutputM[i,j] = LowerM[i,j]
                
        for i in range(Dimension[0]):
            for j in range(i,Dimension[0]):
                OutputM[i,j] = UpperM[i,j]
                
        Det = 1 #This part is for calculating the determinant 
        for i in range(Dimension[0]):
            Det = Det*LowerM[i,i]
                
        return LowerM, UpperM, Det, OutputM
    
    
    def MatrixEqn (self, Linput= np.array([[0,0],[0,0]]) , Uinput= np.array([[0,0],[0,0]]), Binput= np.array([[0,0],[0,0]])):
        
        Dimension = Binput.shape
        Ux = np.zeros(Dimension)
        Output = np.zeros(Dimension)
        
        for i in range(1,Dimension[0]): #This part is for the forward substitution
            Ux[0,0] = Binput[0,0]/Linput[0,0]
            SumF = sum(Linput[i,j]*Ux[j,0] for j in range(i))
            Ux[i,0] =( Binput [i,0] - SumF)/Linput[i,i] 
            
        for i in range(Dimension[0]-2,-1,-1): #This part is for the backwards substitution
            Output[Dimension[0]-1,0] = Ux[Dimension[0]-1,0]/Uinput[Dimension[0]-1,Dimension[0]-1]
            SumB = sum(Uinput[i,j]*Output[j,0] for j in range(i+1,Dimension[0]))
            Output[i,0] = (Ux[i,0]-SumB)/Uinput[i,i]
        
        return Output
    


class Inter:
    def CSI(self,xdata= np.array([[0,0,0,0]]),ydata= np.array([[0,0,0,0]]),xpoints = np.array([[0,0,0,0]]) ): #This is a function for the cubic spline interpolation
        
        ListSize = len(xdata)
        
        OpMatrix = np.zeros((ListSize,ListSize))
        bmatrix = np.zeros((ListSize,1))
        
        OpMatrix[0,0] = 1
        OpMatrix[ListSize-1,ListSize-1]= 1
        
        for i in range(1,(ListSize-1)):
            
            bmatrix[i,0] = (ydata[i+1] - ydata[i])/(xdata[i+1] - xdata[i]) - (ydata[i] - ydata[i-1])/(xdata[i] - xdata[i-1])
            
            
            OpMatrix[i,i-1] = (xdata[i]-xdata[i-1])/6 #This part is using the formula
            OpMatrix[i,i] = (xdata[i+1]-xdata[i-1])/3
            OpMatrix[i,i+1] = (xdata[i+1]-xdata[i])/6
            
        dummy = MM() #Calling the matrix class from previous sections used for Q2
        midout = dummy.CroutMethod(OpMatrix)
        
        InF = dummy.MatrixEqn(midout[0],midout[1],bmatrix)
            
        Outputy = []
        for x in xpoints:
            for i in range(ListSize -1):
                if x >= xdata[i] and x < xdata[i+1]:
                    fA =  (xdata[i+1] - x)/(xdata[i+1] - xdata[i])  #Calculating for the interppolation y coordinates
                    fB =  1 - fA
                    fC =  (fA**3 - fA)*(xdata[i+1] - xdata[i])**2/6
                    fD =  (fB**3 - fB)*(xdata[i+1] - xdata[i])**2/6
                    Outputy.append(fA*ydata[i] + fB*ydata[i+1] + fC*InF[i] + fD*InF[i+1])
                    
            if x == np.amax(xdata):
                fA = (xdata[ListSize-1] - x)/(xdata[ListSize-1] - xdata[ListSize-2])
                fB = 1-fA
                fC = (fA**3 - fA)*(xdata[ListSize-1] - xdata[ListSize-2])**2/6
                fD = (fB**3 - fB)*(xdata[ListSize-1] - xdata[ListSize-2])**2/6
                Outputy.append(fA*ydata[ListSize-2] + fB*ydata[ListSize-1] + fC*InF[ListSize-2] + fD*InF[ListSize-1])
                    
                    
        return Outputy
    
    
    
def chifunction_s(plus_or_minus,k_i,k_j):
    if str(plus_or_minus) == 'plus':
        chi = 0.5* ( np.sqrt(k_j / k_i ) + np.sqrt(k_i / k_j) )
    elif str(plus_or_minus) == 'minus' :
        chi = 0.5* ( np.sqrt(k_j / k_i ) - np.sqrt(k_i / k_j) )
    return chi

def chifunction_p(plus_or_minus,k_i,k_j,n_i,n_j):
    if str(plus_or_minus) == 'plus':
        chi = 0.5*( (n_j/n_i)*np.sqrt(k_i/k_j) + (n_i/n_j)*np.sqrt(k_j/k_i) )
    elif str(plus_or_minus) == 'minus' :
        chi = 0.5*( (n_j/n_i)*np.sqrt(k_i/k_j) - (n_i/n_j)*np.sqrt(k_j/k_i) )
    return chi
    
    


def p_matrix(k_j,d):
    p_matrix = np.array([[np.exp(1j*(k_j * d)) ,0],[ 0, np.exp(-1j*(k_j * d))]])
    return p_matrix



def t_matrix(s_or_p,n_i,n_j,k_i,k_j):
    if str(s_or_p) == 's':
        t_matrix = np.array([ [chifunction_s('plus',k_i,k_j),chifunction_s('minus',k_i,k_j)] ,[chifunction_s('minus',k_i,k_j),chifunction_s('plus',k_i,k_j)] ])
                                  
    elif str(s_or_p) == 'p':
        t_matrix = np.array([[chifunction_p('plus',k_i,k_j,n_i,n_j),chifunction_p('minus',k_i,k_j,n_i,n_j)],[chifunction_p('minus',k_i,k_j,n_i,n_j),chifunction_p('plus',k_i,k_j,n_i,n_j)]])
    return t_matrix


class TransferM:
    '''
    def Tmatrix(a_forward,a_backward,n_i,n_j,k_i,k_j,af_at_ai,ab_at_ai,z_j,z_i,s_or_p):
        
        d = z_j - z_i
        
        
        p_matrix = np.array([[np.exp(1j*(k_j * d)) ,0],[ 0, np.exp(-1j*(k_j * d))]])
        
        if str(s_or_p) == 's':
            t_matrix = np.array([[chifunction_s('plus',k_i,k_j),chifunction_s('minus',k_i,k_j)],[chifunction_s('minus',k_i,k_j),chifunction_s('plus',k_i,k_j)]])
                                  
        elif str(s_or_p) == 'p':
            t_matrix = np.array([[chifunction_p('plus',k_i,k_j,n_i,n_j),chifunction_p('minus',k_i,k_j,n_i,n_j)],[chifunction_p('minus',k_i,k_j,n_i,n_j),chifunction_p('plus',k_i,k_j,n_i,n_j)]])
            
        m_matrix = np.multiply(p_matrix,t_matrix)
        
        a_i_matrix = np.array([[a_forward],[a_backward]])
        
        a_j_matrix = np.multiply(m_matrix,a_i_matrix)
        
        return a_j_matrix
    '''
    
    
    def Mmatrix(self,list_of_refractiveindex,list_of_position,wavelength,incident_angle,s_or_p):
        
        k_0 = (2*np.pi)/wavelength
        k_x = np.sin(incident_angle) * k_0
        
        '''
        list_of_kz = np.zeros(len(list_of_refractiveindex))
        for i in range(len(list_of_kz)):
            list_of_kz[i] = np.sqrt(k_0**2 * list_of_refractiveindex[i]**2 - k_x**2)
        #print(list_of_kz)
        '''
        
        list_of_kz = np.zeros(0)
        for i in range(len(list_of_refractiveindex)):
            list_of_kz = np.append(list_of_kz, np.sqrt(k_0**2 * list_of_refractiveindex[i]**2 - k_x**2))
        
        
        
        thickness_of_layers = np.zeros(len(list_of_position)-1)
        #print(list_of_position)
        
        
        for i in range(len(list_of_position)-1):
            thickness_of_layers[i] = list_of_position[i+1] - list_of_position[i]
        #print(thickness_of_layers)
            
        
        M_matrix = np.array([[1,0],[0,1]])
        
        for i in range(len(thickness_of_layers)):
            #print(p_matrix(list_of_kz[i+1],thickness_of_layers[i]))
            #print(t_matrix(s_or_p,list_of_refractiveindex[i],list_of_refractiveindex[i+1],list_of_kz[i],list_of_kz[i+1]))
            update_matrix = np.dot(p_matrix(list_of_kz[i+1],thickness_of_layers[i]),t_matrix(s_or_p,list_of_refractiveindex[i],list_of_refractiveindex[i+1],list_of_kz[i],list_of_kz[i+1]))
            #print(update_matrix)
            M_matrix = np.dot(update_matrix,M_matrix)
        
        #print(t_matrix(s_or_p,list_of_refractiveindex[-2],list_of_refractiveindex[-1],list_of_kz[i],list_of_kz[-1]))
        
        M_matrix = np.dot(t_matrix(s_or_p,list_of_refractiveindex[-2],list_of_refractiveindex[-1],list_of_kz[-2],list_of_kz[-1]),M_matrix)
        
        r = - (M_matrix[1][0])/(M_matrix[1][1])
        t = M_matrix[0][0] + M_matrix[0][1] * (r)
        
        Reflect = np.absolute(r)**2
        Transm = np.absolute(t)**2
        
        return r, Reflect, Transm
    



































